#ifndef WINDOW2_H
#define WINDOW2_H
#include "maintask.h"
#include <QDialog>

namespace Ui {
class window2;
}

class window2 : public QDialog
{
    Q_OBJECT

public:
    explicit window2(QWidget *parent = nullptr, bool isNew = true);
    ~window2();
    void setMainTaskReference(MainTask* mainTask);
    void setTask(Task task);


signals:
    void saveTask(const QString& task, const QDate& dateTime, int priority);

public slots:
    void on_saveButton_clicked();

private slots:
    void on_cancelButton_clicked();

private:
    Ui::window2 *ui;
    MainTask* mainTaskReference;
    bool newTask;
    Task task;
};

#endif // WINDOW2_H

#ifndef MAINTASK_H
#define MAINTASK_H

#include <QMainWindow>
#include <QStandardPaths>
#include <QLineEdit>
#include "list.h"
#include "ui_maintask.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainTask;
}
QT_END_NAMESPACE

class MainTask : public QMainWindow {
    Q_OBJECT

public:
    MainTask(QWidget *parent = nullptr);
    ~MainTask();

public slots:
    void updateTodoList();
    void onAddTask(QString task, QDate dateTime, int priority);
    void onEditTask(QString task, QDate dateTime, int priority, Task task2);
    void onItemDoubleClicked(QListWidgetItem* item);
    void editTask(QListWidgetItem* item);

private slots:

    void on_removeButton_clicked();

    void on_addButton_clicked();


    void on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous);

private:
    List todoList; // Instance of the List class
    Ui::MainTask *ui;
 //   QString path = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "todo.txt";

    QString path = "todo.txt";

};

#endif // MAINTASK_H


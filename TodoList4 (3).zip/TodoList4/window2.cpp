#include "window2.h"
#include "ui_window2.h"
#include "maintask.h"
#include <QMessageBox>

window2::window2(QWidget *parent, bool isNew)
    : QDialog(parent)
    , ui(new Ui::window2)
    , newTask(isNew)
{
    ui->setupUi(this);

    connect(ui->txt, SIGNAL(returnPressed()), this, SLOT(on_saveButton_clicked()));
    ui->txt->setFocus();

    if(isNew)
        this->setWindowTitle("Add Task");
    else{
        this->setWindowTitle("Edit Task");
    }


}

window2::~window2()
{
    delete ui;
}


void window2::on_saveButton_clicked()
{
    if (mainTaskReference) {
        QString myTextAdd = ui->txt->text().trimmed(); // Get the text without leading/trailing whitespace
        if (myTextAdd.isEmpty()) {
            // Alert the user about the empty task entry (you can use QMessageBox or other UI elements)
            QMessageBox::information(this, "Empty Task", "Please enter a valid task.");
            ui->txt->clear();
            ui->txt->setFocus();
            return; // Exit without adding an empty task
        }
        QDate dateTime = ui->dateEdit->date();
        int priority = ui->spinBox->value(); // Get priority from spin box

        if(newTask)
            mainTaskReference->onAddTask(myTextAdd, dateTime, priority);

        else {
            mainTaskReference->onEditTask(myTextAdd, dateTime, priority, task);
        }
   }

    close();


}

void window2::setMainTaskReference(MainTask* mainTask) {
    mainTaskReference = mainTask; // Set the MainTask reference
}

void window2::setTask(Task myTask){
    task = myTask;
    ui->txt->setText( QString::fromStdString(task.getTask()));
    ui->spinBox->setValue(task.getPriority()); /////NOT WORKING
    ui->dateEdit->setDate(task.getDueDate()); /////NOT WORKING

}
void window2::on_cancelButton_clicked()
{
    close();
}


#include "maintask.h"
#include "ui_maintask.h"
#include "window2.h"
#include <QListWidgetItem>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include<QDebug>


MainTask::MainTask(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainTask),
    todoList() // Initialize todoList here
{
    ui->setupUi(this);
    this->setWindowTitle("To Do List");
    QIcon icon("todo.jpeg"); // Replace ":/path/to/your/icon.png" with the actual path to your icon file
    this->setWindowIcon(icon);
    //listWidget = ui->listWidget;

   // todoList.readFromFile();
   // updateTodoList();
    //todoList.readFromFile();

    //QFile inputFile(file);


    QFile file(path);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Unable to open file for reading.";
        return;
    }
    auto in = QTextStream(&file);
    while (!in.atEnd()) {
        const QString line = in.readLine();
        const QStringList parts = line.split(' ');
        if (parts.size() >= 3) {
            const QString priority = parts[0].trimmed();
            const QString dateString = parts[1].trimmed();
            const QString task = line.mid(parts[0].length()+parts[1].length()+2).trimmed();
            const QDate taskDate = QDate::fromString(dateString, "d/M/yyyy");
            todoList.insert(Task(task.toStdString(), taskDate, priority.toInt()));
        } else
            qDebug() << "Invalid line: " << line;
    }
    file.close();


   //QFont font;
    //font.setFamily("MV Boli");
    //font.setPointSize(12);
  //  QFile file(path);
    if (!file.open(QIODevice::ReadWrite)) {
        QMessageBox::information(0, "Error", file.errorString());
    } else {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QListWidgetItem* item = new QListWidgetItem(in.readLine(), ui->listWidget);
            ui->listWidget->addItem(item);
            //item->setFont(font);
            //item->setFlags(item->flags() | Qt::ItemIsEditable);

        }
        file.close();
    }

    connect(ui->listWidget, &QListWidget::itemDoubleClicked, this, &MainTask::onItemDoubleClicked);
}



// Slot implementation for item double-click
void MainTask::onItemDoubleClicked(QListWidgetItem* item) {
    // Check if an item is double-clicked
    if (item) {
        editTask(item);
    }
}


void MainTask::updateTodoList() {
    ui->listWidget->clear();
    List::Node* p = todoList.first;
    while (p != nullptr){
        QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(p->data.getTask()), ui->listWidget);
        ui->listWidget->addItem(item);
        // Consider adding additional properties or icons for each item if needed
        p = p->next;
    }

    //todoList.writeInFile();

    //QFont font;
    //font.setFamily("MV Boli");
    //font.setPointSize(12);
    QFile file(path);
    if (!file.open(QIODevice::ReadWrite)) {
        QMessageBox::information(0, "Error", file.errorString());
    } else {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QListWidgetItem* item = new QListWidgetItem(in.readLine(), ui->listWidget);
            ui->listWidget->addItem(item);
            //item->setFont(font);
            //item->setFlags(item->flags() | Qt::ItemIsEditable);
        }
        file.close();
    }
}







MainTask::~MainTask() {
    delete ui;
    QFile file(path);
    if (!file.open(QIODevice::ReadWrite)) {
        QMessageBox::information(0, "Error", file.errorString());
    } else {
        QTextStream out(&file);
        for (int i = 0; i < ui->listWidget->count(); i++) {
            out << ui->listWidget->item(i)->text() << "\n";
        }
        file.close();
    }
}



void MainTask::on_removeButton_clicked()
{   QString myTextRemove;
    QListWidgetItem* selectedItem = ui->listWidget->currentItem();
    if (selectedItem) {
        myTextRemove = selectedItem->text();

       /* QListWidgetItem* item= ui->listWidget->takeItem(ui->listWidget->currentRow());
        delete selectedItem;
*/
        Task task(myTextRemove.toStdString());
        todoList.remove(task);
        updateTodoList();
    }
    else
        QMessageBox::information(this, "Invalid input", "Please choose a task");
}



void MainTask::on_addButton_clicked()
{
    window2* newWindow = new window2(this, true); // Pass MainWindow as parent
    newWindow->setMainTaskReference(this); // Pass the reference of MainTask
    newWindow->show();
}

void MainTask::editTask(QListWidgetItem* item){
    window2* newWindow2 = new window2(this, false); // Pass MainWindow as parent
    newWindow2->setMainTaskReference(this); // Pass the reference of MainTask
    QString myText = item->text();
    Task task(myText.toStdString());
    List::Node* p;
    todoList.search(task, p);
    newWindow2->setTask(p->data); // Pass the reference of MainTask
    newWindow2->show();
}

void MainTask::onAddTask(QString task, QDate dateTime, int priority) {

    // Create a Task object based on user inputs
    Task newTask(task.toStdString());
    newTask.setDueDate(dateTime);
    newTask.setPriority(priority);

    // Add the task to the list widget
    todoList.insert(newTask);
    updateTodoList();
}

void MainTask::onEditTask(QString task, QDate dateTime, int priority, Task oldTask) {

    // Create a Task object based on user inputs
    Task newTask(task.toStdString());
    newTask.setDueDate(dateTime);
    newTask.setPriority(priority);
    if(priority == oldTask.getPriority()){
        todoList.insert(newTask);
        todoList.remove(oldTask);
    }
    else{
    // Add the task to the list widget
    todoList.edit(newTask, oldTask);
    }

    updateTodoList();
}



#include "maintask.h"
#include "list.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainTask w;
    w.show();
    return a.exec();
}

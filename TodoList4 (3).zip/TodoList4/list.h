#ifndef LIST_H
#define LIST_H
#include <QWidget>
#include <QObject>
#include <QString>  // Include Qt QString class
#include <QDebug>   // Include Qt Debugging module for qDebug
#include <QDate>
#include <QFile>

class Task {

private:
    std::string myTask;  // Use QString instead of std::string
    QDate dueDate;
    int priority;

public:
    Task(){};
    Task(std::string task) : myTask(task), priority(1){};
    Task(std::string task, int p) : myTask(task), priority(p){};
    Task(std::string task, QDate date, int p) : myTask(task), priority(p), dueDate(date){};

    Q_INVOKABLE int getPriority() const;
    Q_INVOKABLE std::string getTask() const;  // Use QString instead of std::string
    Q_INVOKABLE QDate getDueDate()const ;
    Q_INVOKABLE void setTask(std::string t);
    Q_INVOKABLE void setDueDate(const QDate& dateTime);
    Q_INVOKABLE void setPriority(int priorityValue);
};

Q_DECLARE_METATYPE(Task);  // Declare Task as a metatype for signals/slots

typedef Task Type;

class List : public QObject {
    Q_OBJECT
    QFile file;
public:
    class Node {
    public:
        Type data;
        Node* next;
        Node(Type info) : data(info), next(nullptr){};
    };
    Node* first;
    Node* last;
    int size;

    List();
    ~List();
    Q_INVOKABLE bool empty() const;
    Q_INVOKABLE void insert(const Type& item);
    Q_INVOKABLE void remove(const Type& item);
    Q_INVOKABLE void search(const Type& item, Node*& p) const;
    Q_INVOKABLE void edit(Type& newItem, Type& oldItem);

    Q_INVOKABLE void writeInFile() ;
    Q_INVOKABLE void readFromFile();

};

#endif

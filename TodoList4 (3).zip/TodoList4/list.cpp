#include "list.h"
#include <QDebug>
#include <QMessageBox>
#include <QStandardPaths>


int Task::getPriority() const {
    return priority;
}
void Task::setDueDate(const QDate& date) {
    dueDate = date;
}

void Task::setPriority(int priorityValue) {
    priority = priorityValue;
}

void Task::setTask(std::string t) {
    myTask = t;
}
std::string Task::getTask() const {
    return myTask;
}

QDate Task::getDueDate() const{
    return dueDate ;
}

List::List():file("todo.txt"), first(nullptr), last(nullptr), size(0){}

List::~List() {
    Node* pre = first, *ptr;
    while (pre != 0) {
        ptr = pre->next;
        delete pre;
        pre = ptr;
    }
}


bool List::empty() const {
    return !first;
}


void List::search(const Type& task, Node*& p) const {
    if (empty()) {
        p = nullptr;
        return;
    }
    p = first;
    while (p != nullptr) {
        if (p->data.getTask() == task.getTask()) break;
        p = p->next;
    }
}


void List::insert(const Type& task) {
    Node* p;
    search(task, p);
    int taskP = task.getPriority();
    QDate taskD = task.getDueDate();

    if (p == nullptr) {
        size++;
        Node* newPtr = new Node(task);
        if (empty())
            first = last = newPtr;
        else {
            Node* prvs = first;
            while (prvs->next != nullptr && prvs->next->data.getDueDate() < taskD)
                prvs = prvs->next;
            if (taskP > prvs->data.getPriority()) {
                newPtr->next = prvs->next;
                prvs->next = newPtr;
            } else {
                while (prvs->next != nullptr && prvs->next->data.getDueDate() == taskD && prvs->next->data.getPriority() >= taskP) {
                    prvs = prvs->next;
                }
                newPtr->next = prvs->next;
                prvs->next = newPtr;
                if (newPtr->next == nullptr) {
                    last = newPtr;
                }
            }
        }
    }
    else qDebug() << "Task already exists.";
}

void List::remove(const Type& task) {
    Node* delPtr;
    search(task, delPtr);
    if (delPtr == nullptr) {
        qDebug() << "Task doesn't exist";
        return;
    }

    Node* prev = first;
    if (delPtr == first)
        first = prev->next;
    else {
        while (prev->next != delPtr) {
            prev = prev->next;
        }
        if (delPtr == last)
            last = prev;
    }

    prev->next = delPtr->next;
    delete delPtr;
    size--;

    //writeInFile();
}




void List::writeInFile() {
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //QMessageBox::critical(nullptr, "Error", "Unable to open file for writing.");
        return;
    }
    // Clear the existing content in the file
    if (!file.resize(0)) {
        //QMessageBox::critical(nullptr, "Error", "Unable to clear the existing content in the file.");
        return;
    }

    auto out = QTextStream(&file);
    for (Node* p = first; p != nullptr; p = p->next) {
        // Format the output line with priority, date, and task
        //out << p->data.getPriority() << " " << p->data.getDueDate().toString("d/M/yyyy") << " " <<QString::fromStdString(p->data.getTask()) << "\n";

    }
    file.close();
}


void List::edit(Type& newItem, Type& oldItem){
    Node* oldPtr, *newPtr;
    search(oldItem, oldPtr);
    if(oldItem.getPriority() == newItem.getPriority()){
        //if(oldItem.getTask() != newItem.getTask()){
        search(newItem, newPtr);
        if((newPtr != 0) && (oldItem.getTask() != newItem.getTask())){
            qDebug() << "Task already exists";
            return;
        }
        //}
        oldPtr -> data = newItem;

    }else{
        remove(oldItem);
        insert(newItem);
    }


    //writeInFile();

}

void List::readFromFile() {
    //QFile inputFile(file);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Unable to open file for reading.";
        return;
    }
    auto in = QTextStream(&file);
    while (!in.atEnd()) {
        const QString line = in.readLine();
        const QStringList parts = line.split(' ');
        if (parts.size() >= 3) {
            const QString priority = parts[0].trimmed();
            const QString dateString = parts[1].trimmed();
            const QString task = line.mid(parts[0].length()+parts[1].length()+2).trimmed();
            const QDate taskDate = QDate::fromString(dateString, "d/M/yyyy");
            insert(Task(task.toStdString(), taskDate, priority.toInt()));
        } else
            qDebug() << "Invalid line: " << line;
    }
    file.close();



}

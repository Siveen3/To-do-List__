/********************************************************************************
** Form generated from reading UI file 'window2.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WINDOW2_H
#define UI_WINDOW2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_window2
{
public:
    QWidget *widget;
    QSpinBox *spinBox;
    QLabel *label;
    QWidget *widget_2;
    QLabel *label_2;
    QDateEdit *dateEdit;
    QLineEdit *txt;
    QLabel *label_3;
    QPushButton *cancelButton;
    QPushButton *saveButton;

    void setupUi(QDialog *window2)
    {
        if (window2->objectName().isEmpty())
            window2->setObjectName("window2");
        window2->resize(235, 172);
        window2->setModal(false);
        widget = new QWidget(window2);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(30, 40, 171, 31));
        spinBox = new QSpinBox(widget);
        spinBox->setObjectName("spinBox");
        spinBox->setGeometry(QRect(130, 0, 41, 31));
        spinBox->setMinimum(1);
        spinBox->setMaximum(5);
        label = new QLabel(widget);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 91, 31));
        widget_2 = new QWidget(window2);
        widget_2->setObjectName("widget_2");
        widget_2->setGeometry(QRect(30, 80, 171, 51));
        label_2 = new QLabel(widget_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(0, -10, 91, 31));
        dateEdit = new QDateEdit(widget_2);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setGeometry(QRect(60, 20, 110, 25));
        txt = new QLineEdit(window2);
        txt->setObjectName("txt");
        txt->setGeometry(QRect(40, 10, 161, 24));
        label_3 = new QLabel(window2);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 10, 31, 21));
        cancelButton = new QPushButton(window2);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setGeometry(QRect(120, 130, 80, 24));
        saveButton = new QPushButton(window2);
        saveButton->setObjectName("saveButton");
        saveButton->setGeometry(QRect(30, 130, 80, 24));

        retranslateUi(window2);

        QMetaObject::connectSlotsByName(window2);
    } // setupUi

    void retranslateUi(QDialog *window2)
    {
        window2->setWindowTitle(QCoreApplication::translate("window2", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("window2", "Select priority", nullptr));
        label_2->setText(QCoreApplication::translate("window2", "Choose task date", nullptr));
        label_3->setText(QCoreApplication::translate("window2", "Task:", nullptr));
        cancelButton->setText(QCoreApplication::translate("window2", "Cancel", nullptr));
        saveButton->setText(QCoreApplication::translate("window2", "Save", nullptr));
    } // retranslateUi

};

namespace Ui {
    class window2: public Ui_window2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WINDOW2_H

/****************************************************************************
** Meta object code from reading C++ file 'list.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../TodoList4/list.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'list.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSListENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSListENDCLASS = QtMocHelpers::stringData(
    "List",
    "empty",
    "",
    "insert",
    "Type",
    "item",
    "remove",
    "search",
    "Node*&",
    "p",
    "edit",
    "Type&",
    "newItem",
    "oldItem",
    "writeInFile",
    "readFromFile"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSListENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[5];
    char stringdata1[6];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[5];
    char stringdata5[5];
    char stringdata6[7];
    char stringdata7[7];
    char stringdata8[7];
    char stringdata9[2];
    char stringdata10[5];
    char stringdata11[6];
    char stringdata12[8];
    char stringdata13[8];
    char stringdata14[12];
    char stringdata15[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSListENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSListENDCLASS_t qt_meta_stringdata_CLASSListENDCLASS = {
    {
        QT_MOC_LITERAL(0, 4),  // "List"
        QT_MOC_LITERAL(5, 5),  // "empty"
        QT_MOC_LITERAL(11, 0),  // ""
        QT_MOC_LITERAL(12, 6),  // "insert"
        QT_MOC_LITERAL(19, 4),  // "Type"
        QT_MOC_LITERAL(24, 4),  // "item"
        QT_MOC_LITERAL(29, 6),  // "remove"
        QT_MOC_LITERAL(36, 6),  // "search"
        QT_MOC_LITERAL(43, 6),  // "Node*&"
        QT_MOC_LITERAL(50, 1),  // "p"
        QT_MOC_LITERAL(52, 4),  // "edit"
        QT_MOC_LITERAL(57, 5),  // "Type&"
        QT_MOC_LITERAL(63, 7),  // "newItem"
        QT_MOC_LITERAL(71, 7),  // "oldItem"
        QT_MOC_LITERAL(79, 11),  // "writeInFile"
        QT_MOC_LITERAL(91, 12)   // "readFromFile"
    },
    "List",
    "empty",
    "",
    "insert",
    "Type",
    "item",
    "remove",
    "search",
    "Node*&",
    "p",
    "edit",
    "Type&",
    "newItem",
    "oldItem",
    "writeInFile",
    "readFromFile"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSListENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   56,    2, 0x102,    1 /* Public | MethodIsConst  */,
       3,    1,   57,    2, 0x02,    2 /* Public */,
       6,    1,   60,    2, 0x02,    4 /* Public */,
       7,    2,   63,    2, 0x102,    6 /* Public | MethodIsConst  */,
      10,    2,   68,    2, 0x02,    9 /* Public */,
      14,    0,   73,    2, 0x02,   12 /* Public */,
      15,    0,   74,    2, 0x02,   13 /* Public */,

 // methods: parameters
    QMetaType::Bool,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 8,    5,    9,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 11,   12,   13,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject List::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSListENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSListENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSListENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<List, std::true_type>,
        // method 'empty'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'insert'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Type &, std::false_type>,
        // method 'remove'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Type &, std::false_type>,
        // method 'search'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Type &, std::false_type>,
        QtPrivate::TypeAndForceComplete<Node * &, std::false_type>,
        // method 'edit'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Type &, std::false_type>,
        QtPrivate::TypeAndForceComplete<Type &, std::false_type>,
        // method 'writeInFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'readFromFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void List::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<List *>(_o);
        (void)_t;
        switch (_id) {
        case 0: { bool _r = _t->empty();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 1: _t->insert((*reinterpret_cast< std::add_pointer_t<Type>>(_a[1]))); break;
        case 2: _t->remove((*reinterpret_cast< std::add_pointer_t<Type>>(_a[1]))); break;
        case 3: _t->search((*reinterpret_cast< std::add_pointer_t<Type>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Node*&>>(_a[2]))); break;
        case 4: _t->edit((*reinterpret_cast< std::add_pointer_t<Type&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Type&>>(_a[2]))); break;
        case 5: _t->writeInFile(); break;
        case 6: _t->readFromFile(); break;
        default: ;
        }
    }
}

const QMetaObject *List::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *List::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSListENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int List::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP

/****************************************************************************
** Meta object code from reading C++ file 'maintask.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../TodoList4/maintask.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'maintask.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainTaskENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainTaskENDCLASS = QtMocHelpers::stringData(
    "MainTask",
    "updateTodoList",
    "",
    "onAddTask",
    "task",
    "dateTime",
    "priority",
    "onEditTask",
    "Task",
    "task2",
    "onItemDoubleClicked",
    "QListWidgetItem*",
    "item",
    "editTask",
    "on_removeButton_clicked",
    "on_addButton_clicked",
    "on_listWidget_currentItemChanged",
    "current",
    "previous"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainTaskENDCLASS_t {
    uint offsetsAndSizes[38];
    char stringdata0[9];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[10];
    char stringdata4[5];
    char stringdata5[9];
    char stringdata6[9];
    char stringdata7[11];
    char stringdata8[5];
    char stringdata9[6];
    char stringdata10[20];
    char stringdata11[17];
    char stringdata12[5];
    char stringdata13[9];
    char stringdata14[24];
    char stringdata15[21];
    char stringdata16[33];
    char stringdata17[8];
    char stringdata18[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainTaskENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainTaskENDCLASS_t qt_meta_stringdata_CLASSMainTaskENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "MainTask"
        QT_MOC_LITERAL(9, 14),  // "updateTodoList"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 9),  // "onAddTask"
        QT_MOC_LITERAL(35, 4),  // "task"
        QT_MOC_LITERAL(40, 8),  // "dateTime"
        QT_MOC_LITERAL(49, 8),  // "priority"
        QT_MOC_LITERAL(58, 10),  // "onEditTask"
        QT_MOC_LITERAL(69, 4),  // "Task"
        QT_MOC_LITERAL(74, 5),  // "task2"
        QT_MOC_LITERAL(80, 19),  // "onItemDoubleClicked"
        QT_MOC_LITERAL(100, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(117, 4),  // "item"
        QT_MOC_LITERAL(122, 8),  // "editTask"
        QT_MOC_LITERAL(131, 23),  // "on_removeButton_clicked"
        QT_MOC_LITERAL(155, 20),  // "on_addButton_clicked"
        QT_MOC_LITERAL(176, 32),  // "on_listWidget_currentItemChanged"
        QT_MOC_LITERAL(209, 7),  // "current"
        QT_MOC_LITERAL(217, 8)   // "previous"
    },
    "MainTask",
    "updateTodoList",
    "",
    "onAddTask",
    "task",
    "dateTime",
    "priority",
    "onEditTask",
    "Task",
    "task2",
    "onItemDoubleClicked",
    "QListWidgetItem*",
    "item",
    "editTask",
    "on_removeButton_clicked",
    "on_addButton_clicked",
    "on_listWidget_currentItemChanged",
    "current",
    "previous"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainTaskENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   62,    2, 0x0a,    1 /* Public */,
       3,    3,   63,    2, 0x0a,    2 /* Public */,
       7,    4,   70,    2, 0x0a,    6 /* Public */,
      10,    1,   79,    2, 0x0a,   11 /* Public */,
      13,    1,   82,    2, 0x0a,   13 /* Public */,
      14,    0,   85,    2, 0x08,   15 /* Private */,
      15,    0,   86,    2, 0x08,   16 /* Private */,
      16,    2,   87,    2, 0x08,   17 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QDate, QMetaType::Int,    4,    5,    6,
    QMetaType::Void, QMetaType::QString, QMetaType::QDate, QMetaType::Int, 0x80000000 | 8,    4,    5,    6,    9,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 11,   17,   18,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainTask::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainTaskENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainTaskENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainTaskENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainTask, std::true_type>,
        // method 'updateTodoList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAddTask'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDate, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onEditTask'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDate, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<Task, std::false_type>,
        // method 'onItemDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'editTask'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'on_removeButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_listWidget_currentItemChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>
    >,
    nullptr
} };

void MainTask::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainTask *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->updateTodoList(); break;
        case 1: _t->onAddTask((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDate>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 2: _t->onEditTask((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDate>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<Task>>(_a[4]))); break;
        case 3: _t->onItemDoubleClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 4: _t->editTask((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 5: _t->on_removeButton_clicked(); break;
        case 6: _t->on_addButton_clicked(); break;

        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 3:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Task >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainTask::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainTask::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainTaskENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainTask::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP

/********************************************************************************
** Form generated from reading UI file 'maintask.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINTASK_H
#define UI_MAINTASK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainTask
{
public:
    QWidget *centralwidget;
    QPushButton *addButton;
    QPushButton *removeButton;
    QListWidget *listWidget;

    void setupUi(QMainWindow *MainTask)
    {
        if (MainTask->objectName().isEmpty())
            MainTask->setObjectName("MainTask");
        MainTask->resize(351, 399);
        centralwidget = new QWidget(MainTask);
        centralwidget->setObjectName("centralwidget");
        addButton = new QPushButton(centralwidget);
        addButton->setObjectName("addButton");
        addButton->setGeometry(QRect(180, 370, 71, 24));
        removeButton = new QPushButton(centralwidget);
        removeButton->setObjectName("removeButton");
        removeButton->setGeometry(QRect(260, 370, 71, 24));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(10, 10, 331, 351));
        MainTask->setCentralWidget(centralwidget);

        retranslateUi(MainTask);

        QMetaObject::connectSlotsByName(MainTask);
    } // setupUi

    void retranslateUi(QMainWindow *MainTask)
    {
        MainTask->setWindowTitle(QCoreApplication::translate("MainTask", "MainTask", nullptr));
        addButton->setText(QCoreApplication::translate("MainTask", "Add", nullptr));
        removeButton->setText(QCoreApplication::translate("MainTask", "Remove", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainTask: public Ui_MainTask {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINTASK_H
